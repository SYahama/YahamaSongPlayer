import tkinter as tk
from tkinter import ttk
import os
import pygame
from PIL import Image, ImageTk


pygame.mixer.init()

def play_song(song_path):
    pygame.mixer.music.load(song_path)
    pygame.mixer.music.play()

def stop_all_songs():
    pygame.mixer.music.stop()

def load_songs():
    folder = "songs"  
    songs = [f for f in os.listdir(folder) if f.endswith(".mp3")]
    
    for song in songs:
        song_path = os.path.join(folder, song)
        btn = ttk.Button(root, text=song, command=lambda p=song_path: play_song(p), style="Custom.TButton")
        btn.pack(pady=5, padx=20, fill='x')
        
root = tk.Tk()
root.title("YahamaPlay")
root.geometry("400x500")
root.configure(bg="#222")

style = ttk.Style()
style.configure("Custom.TButton", font=("Arial", 12), padding=10, foreground="white", background="#444")
style.map("Custom.TButton", background=[("active", "#666")])

title_label = ttk.Label(root, text="YahamaPlay", font=("Arial", 16, "bold"), foreground="white", background="#222")
title_label.pack(pady=10)

stop_button = ttk.Button(root, text="Stop All Songs", command=stop_all_songs, style="Custom.TButton")
stop_button.pack(pady=10, padx=20, fill='x')


load_songs()

root.mainloop()